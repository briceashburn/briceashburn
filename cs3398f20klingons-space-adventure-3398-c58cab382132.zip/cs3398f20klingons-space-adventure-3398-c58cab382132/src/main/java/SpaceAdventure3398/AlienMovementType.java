


public interface AlienMovementType
{
	public int move(int speed, int direction);
}
